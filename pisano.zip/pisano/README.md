## Install dependencies

Run `npm i`

## Run Cypress tests

Run `npx cypress run` or `npx cypress open`


This document was created by Olus Cansu Arioz for Pisano under the QA UI Automation Challenge.

The test cases can be found in the pisano.cy.js file.